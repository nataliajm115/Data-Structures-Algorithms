#include <stdio.h>
#include <stdlib.h>
#include "libs/LibList.h"

// Write a function that sorts a list.

List sort(List li) {
  // ...
  return li;
}

// do not modify the main function
int main(void) {
  int count = 0;
  printf("How many numbers?\n");
  scanf("%d", &count);
  List li = newEmptyList();
  printf("Please enter the numbers, one per line:\n");
  int next = 0;
  while (count > 0) {
    scanf("%d", &next);
    li = addItem(next, li);
    count--;
  }
  printf("The original list: ");
  printList(li);
  printf("\n");
  li = sort(li);
  printf("The sorted list: ");
  printList(li);
  printf("\n");
  freeList(li);
  exit(0);
}
