#include <stdio.h>
#include <stdlib.h>

#include "libs/LibStack.h"

int main(void) {
  // Write a program that creates a stack,
  // asks the user for 3 integers, pushes
  // them on the stack, and then pops and
  // prints them again.

  // ...

  printf("What is the first number?\n");

  // ...

  printf("What is the second number?\n");

  // ...

  printf("What is the third number?\n");

  // ...

  printf("Now we will pop from the stack.\n");

  // ...

  exit(0);
}
