#include <stdio.h>

int main(void) {
  // Write a program that first asks "What is n?",
  // reads in a number and then prints the first n
  // many lines of Pascal's triangle.
  //
  // See https://en.wikipedia.org/wiki/Pascal%27s_triangle

  printf("What is n?\n");
  int numberOfRows = 10;
  scanf("%d", &numberOfRows);

  // ...

}
