#include <stdio.h>
#include <stdlib.h>

// Define a struct for points in three dimensional
// space where the coordinates are floats.

// ...

// Write a function to check whether three given
// points are lying on a line.

// ...

int main(void) {
  // Then write a main function which asks "What is the first point" etc.
  // and then prints YES or NO depending on whether the points are in one
  // line or not.
  // The points should be entered one per line, separated by a space
  // (see tests/1.input.txt for an example).

  // ...

  exit(0);
}
