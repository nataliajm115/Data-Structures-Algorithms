#include <stdio.h>

int main(void) {
  printf("\nThe program did run!\n\n");
}
