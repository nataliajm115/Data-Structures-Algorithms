#include <stdio.h>
#include <stdlib.h>

int main(void) {
  // Write a program that asks "What is n?",
  // then uses malloc to create an int-array
  // of size n, then keeps asking "What is the next number?"
  // to read in n many numbers, writes them into the array,
  // and finally prints the whole array in one line, separated by spaces.

  // ...

  exit(0);
}
