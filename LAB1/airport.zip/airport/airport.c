#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "libs/LibStack.h"
#include "libs/LibQueue.h"

// some global constants
const int maxHangar = 5;
const int maxRunway = 7;

// Please read the assignment PDF on Canvas for details!

int main(void) {
  int n; // number of planes to read
  scanf("%d",&n);

  // ...

  return 0;
}
