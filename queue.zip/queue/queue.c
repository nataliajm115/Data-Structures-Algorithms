#include <stdio.h>
#include <stdlib.h>

#include "libs/LibQueue.h"

int main(void) {
  // Write a program that creates a queue,
  // asks the user for 3 integers, enqueues
  // them in the queue, and then dequeues
  // and prints them again.

  // ...

  printf("What is the first number?\n");

  // ...

  printf("What is the second number?\n");

  // ...

  printf("What is the third number?\n");

  // ...

  printf("Now we will dequeue from the queue.\n");

  // ...

  exit(0);
}
