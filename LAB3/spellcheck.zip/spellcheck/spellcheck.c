// Spellcheck Lab assignment

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// maximum length for a word
#define LENGTH 45

// Naive and inefficient way to store a dictionary.
// We use an array of strings.
// Do not edit this for part 1, but replace it for part 2.
typedef struct dict {
  int numWords;
  int maxWords;
  char** words;
} dict;

// Create a new empty dictionary.
// Do not edit this for part 1, but replace it for part 2.
dict* newEmptyDict(void) {
  dict* d = malloc(sizeof(dict));
  if (d == NULL) {
    return NULL;
  }
  d->numWords = 0;
  d->maxWords = 1;
  d->words = malloc(sizeof(char*) * d->maxWords);
  return d;
}

// Check if a word is in the dictionary.
// Do not edit this for part 1, but replace it for part 2.
bool check(const char* word, dict* d) {
  for (int i = 0; i < d->numWords; i++) {
    if (strcmp(d->words[i], word) == 0) {
      return true;
    }
  }
  return false;
}

// Add word to the dictionary if it is is not already known.
// Do not edit this for part 1, but replace it for part 2.
void addWord(char word[LENGTH + 1], dict* d) {
  if (!check(word, d)) {
    // if we need more space before adding the word, double the size
    if (d->numWords == d->maxWords) {
      d->words = realloc(d->words, (sizeof(char*)) * (d->maxWords * 2));
      if (d->words == NULL) {
        printf("Out of memory.\n");
        exit(-1);
      }
      d->maxWords = d->maxWords * 2;
    }
    // now we actually add the word
    d->words[d->numWords] = malloc(sizeof(char) * (LENGTH + 1));
    strcpy(d->words[d->numWords], word);
    d->numWords++;
  }
}

// Free the memory used by the dictionary.
// Do not edit this for part 1, but replace it for part 2.
void freeDict(dict* d) {
  for (int i = 0; i < d->numWords; i++) {
    free(d->words[i]);
  }
  free(d->words);
  free(d);
}

// Remove non-alphabetic characters and convert to lower case.
// You may or may not have to edit this.
void trimWord(char* word) {
  int k = 0;
  for (int i = 0; i < (int)strlen(word); i++) {
    if (isalpha(word[i])) {
      word[k] = tolower(word[i]);
      k++;
    }
  }
  word[k] = '\0';
}

// The main function. You should edit this for part 1.
int main(void) {
  char word[LENGTH + 1] = "";

  // step 1: read in the dictionary
  dict* dictionary = newEmptyDict();
  while (scanf("%45s", word) && word[0] != '%') {
    trimWord(word);
    addWord(word, dictionary);
  }

  // step 2: read in text
  int counter = 0;  // number of unknown words

  // BUG: This loop is wrong. It will read "one,twwo" as one word "onetwwo".
  while (scanf("%45s", word) != EOF) {
    trimWord(word);
    if (!check(word, dictionary)) {
      counter++;
      printf("%s\n", word);
    }
  }
  // TODO: Replace the above while loop with a correct solution.
  // Hints:
  // - you should read one character at a time, using getchar()
  // - alphabetical characters should be appended to the current word
  // - any other symbol should terminate the word
  // this code might be useful:
  /*
  int index = 0;
  int c = EOF;
  while ((c = getchar()) && c != EOF) {
    // ...
  }
  */

  // step 3: print number of unknown words
  printf("%d\n", counter);

  freeDict(dictionary);
  return 0;
}
