#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// See the PDF for LAB2 for instructions!

int main(void) {

  // ...

  int count = 0;
  char command;
  while (1) {
    printf("Currently there are %d patients in the queue.\n", count);
    if (count == 0) {
      printf("What do you want to do? [N]ew patient, [Q]uit:\n");
    } else {
      printf("What do you want to do? [N]ew patient, [T]reat patient, [L]ist, [Q]uit:\n");
    }
    scanf("%c", &command);
    getchar();  // ignore line break after command
    if (command == 'N') {
      char name[201];
      printf("What is the name of the patient?\n");
      scanf("%200[^\n]", name);
      getchar();  // ignore line break after name

      // ...

      count++;
    }
    if (command == 'T') {

      // ...

    }
    if (command == 'L') {

      // ...

    }
    if (command == 'Q') {

      // ...

      printf("Goodbye!\n");
      exit(0);
    }
  }
}
