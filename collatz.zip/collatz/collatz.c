#include <stdio.h>
#include <stdlib.h>

int main(void) {
  // Write a program that asks "What is n?" to read in a number.
  // Then the program should repeatedlt do as follows:
  // If the number is even, divide it by two.
  // If the number is odd, multiply by three and add one.
  // Repeat this until you reach 1, and print the intermediate steps.
  //
  // See also https://en.wikipedia.org/wiki/Collatz_conjecture

  // ...

  exit(0);
}
