#include <stdio.h>
#include <stdlib.h>

int main(void) {
  // First solve the "collatz" exercise from last week.
  // Then write a function collatzLength(n) that given a number n returns the
  // length of the Collatz sequence starting with n and ending with 1.
  //
  // For example, collatzLength(10) should return 7, because the sequence
  // 10, 5, 16, 8, 4, 2, 1 has length 7.

  // Finally, write a main() function which asks the user "What is n?"
  // and then returns the number k <= n such that collatzLength(k) is maximal.

  // Note that this means you have to run collatzLength(k) for all possible
  // numbers up to k.
  // For example, if n is 17, then the answer should be 9 because among
  // the 17 Collatz sequences (starting with 1, starting with 2, etc.)
  // we get the longest sequence when we start with 9.
  // Finally, note that the program should print the starting number of
  // the longest collatz sequence, not the length of the sequence.

  // ...

  exit(0);
}
